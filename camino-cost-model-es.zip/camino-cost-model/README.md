# Camino Cost Model — LCP multivariado con variables históricas (NOA)

Este repositorio ofrece un **pipeline reproducible** para construir una **superficie de coste** multivariada y calcular **Least-Cost Paths (LCP)** en el Noroeste Argentino (NOA), integrando variables **ambientales** (pendiente, altitud, NDVI invertido, tiempo) y **históricas** (riesgo de conflicto).

- Guía detallada de uso: [USAGE.md](./USAGE.md)
- Configuración de ejemplo: `config/example_config.yaml`
- Licencia: MIT

## Instalación rápida
```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

> Nota: en Debian/Ubuntu puede requerirse `gdal-bin` y `libgdal-dev` para Rasterio/Fiona.

## Estructura
```
camino-cost-model/
├─ README.md
├─ USAGE.md
├─ requirements.txt
├─ LICENSE
├─ .gitignore
├─ config/
│  └─ example_config.yaml
└─ src/
   ├─ build_cost_surface.py      # Construye S y Coste = N*(1−S)*C
   ├─ lcp_from_cost.py           # LCP sobre coste (networkx/skimage)
   ├─ lcp_from_slope.py          # LCP solo pendiente (baseline)
   ├─ rasterize_vector.py        # Rasterizar polígonos → ráster
   └─ utils_raster.py            # Normalización, IO, reproyección
```

## Cómo citar
Mignone, P. (2025). *Camino Cost Model: LCP multivariado con variables históricas (NOA)*. GitHub. Versión v1.0.0.  
(Agregue DOI si corresponde).

---

**English short note**: Spanish is the primary language for docs and comments in this repository. See `USAGE.md` for instructions.
