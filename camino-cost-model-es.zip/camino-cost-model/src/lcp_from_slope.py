#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Calcula LCP usando sólo pendiente como coste (línea base)."""
import argparse, os
import numpy as np
import rasterio
import geopandas as gpd
from shapely.geometry import LineString
from skimage.graph import route_through_array

def world_to_pixel(transform, x, y):
    col, row = ~transform * (x, y)
    return int(row), int(col)

def pixel_to_world(transform, row, col):
    x, y = transform * (col + 0.5, row + 0.5)
    return (x, y)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--slope_raster", required=True)
    ap.add_argument("--points_shp", required=True)
    ap.add_argument("--source_name", required=True)
    ap.add_argument("--target_name", required=True)
    ap.add_argument("--out_path", required=True)
    args = ap.parse_args()

    with rasterio.open(args.slope_raster) as src:
        slope = src.read(1).astype("float64")
        transform = src.transform

    pts = gpd.read_file(args.points_shp)
    name_col = "Name" if "Name" in pts.columns else "name"
    src_pt = pts.loc[pts[name_col] == args.source_name].geometry.iloc[0]
    dst_pt = pts.loc[pts[name_col] == args.target_name].geometry.iloc[0]

    src_rc = world_to_pixel(transform, src_pt.x, src_pt.y)
    dst_rc = world_to_pixel(transform, dst_pt.x, dst_pt.y)

    slope = slope.copy()
    finite = np.isfinite(slope)
    if not finite.all():
        max_finite = np.nanmax(slope[finite])
        slope[~finite] = max_finite

    idx, total = route_through_array(slope, src_rc, dst_rc, fully_connected=False, geometric=False)
    coords = [pixel_to_world(transform, r, c) for r, c in idx]

    gdf = gpd.GeoDataFrame({"source":[args.source_name], "target":[args.target_name]}, geometry=[LineString(coords)], crs=pts.crs)
    os.makedirs(os.path.dirname(args.out_path), exist_ok=True)
    gdf.to_file(args.out_path)

if __name__ == "__main__":
    main()
