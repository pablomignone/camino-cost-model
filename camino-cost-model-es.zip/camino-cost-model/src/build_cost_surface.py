#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Construye S y la superficie de Coste = N*(1−S)*C a partir de P, A, V, R, T y pesos."""
import argparse, os, yaml
import numpy as np
from utils_raster import read_array, write_array, normalize01, maybe_invert_ndvi

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", required=True)
    args = ap.parse_args()

    cfg = yaml.safe_load(open(args.config, "r"))
    P_path = cfg["paths"]["slope"]
    A_path = cfg["paths"]["altitude"]
    V_path = cfg["paths"]["ndvi"]
    R_path = cfg["paths"]["risk"]
    T_path = cfg["paths"]["time"]

    out_dir = cfg["output"]["dir"]
    os.makedirs(out_dir, exist_ok=True)
    S_path = os.path.join(out_dir, cfg["output"]["s_raster"])
    Cost_path = os.path.join(out_dir, cfg["output"]["cost_raster"])

    N = float(cfg["history"]["N"])
    C = float(cfg["history"]["C"])

    Wp = float(cfg["weights"]["Wp"])
    Wa = float(cfg["weights"]["Wa"])
    Wr = float(cfg["weights"]["Wr"])
    Wv = float(cfg["weights"]["Wv"])
    Wt = float(cfg["weights"]["Wt"])

    normalize = bool(cfg["preproc"]["normalize"])
    invert_ndvi = bool(cfg["preproc"]["invert_ndvi"])

    P, meta = read_array(P_path)
    A, _ = read_array(A_path)
    V, _ = read_array(V_path)
    R, _ = read_array(R_path)
    T, _ = read_array(T_path)

    if normalize:
        Pn = normalize01(P); An = normalize01(A); Vn = normalize01(V); Rn = normalize01(R); Tn = normalize01(T)
    else:
        Pn, An, Vn, Rn, Tn = P, A, V, R, T

    Vn = maybe_invert_ndvi(Vn, invert=invert_ndvi)  # V = 1 - NDVI_norm

    S = 1.0 - (Wp*Pn + Wa*An + Wr*Rn + Wv*Vn + Wt*Tn)
    S = np.clip(S, 0.0, 1.0)
    Coste = N * (1.0 - S) * C

    write_array(S_path, S, meta)
    write_array(Cost_path, Coste, meta)

if __name__ == "__main__":
    main()
