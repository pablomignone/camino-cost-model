# Guía de uso (USAGE)

## 0) Requisitos
- Python 3.10+ y entorno virtual.
- Instalar dependencias:
```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

## 1) Datos esperados
- Rásteres (GeoTIFF): `pendiente.tif` (P), `altitud.tif` (A), `ndvi.tif` (para V se usa 1−NDVI_norm), `riesgo.tif` (R), `tiempo.tif` (T en segundos).
- Capa de puntos (Shapefile/GPKG) con campo `Name`/`name` para origen y destino.

## 2) Configuración
Copiar y editar:
```bash
cp config/example_config.yaml config/run.yaml
# editar rutas absolutas y pesos Wp, Wa, Wr, Wv, Wt, N y C
```

## 3) Construir S y Coste
```bash
python src/build_cost_surface.py --config config/run.yaml
```
Genera `outputs/Supervivencia.tif` y `outputs/Coste.tif`.

## 4) Calcular LCP multivariado (sobre Coste.tif)
```bash
python src/lcp_from_cost.py   --cost_raster outputs/Coste.tif   --points_shp /ruta/puntos.shp   --source_name "Santiago del Estero"   --target_name "Talina"   --backend networkx   --out_path outputs/LCP_coste.shp
```

## 5) LCP de línea base (solo pendiente)
```bash
python src/lcp_from_slope.py   --slope_raster /ruta/pendiente.tif   --points_shp /ruta/puntos.shp   --source_name "Santiago del Estero"   --target_name "Talina"   --out_path outputs/LCP_pendiente.shp
```

## 6) (Opcional) Mapa comparativo
```bash
python src/compare_paths_map.py   --lcp_cost outputs/LCP_coste.shp   --lcp_slope outputs/LCP_pendiente.shp   --out_png outputs/comparacion.png
```

## Notas
- Todas las capas deben compartir **CRS y rejilla** (resolución y transform).
- V = **1 − NDVI_norm** (escasez de vegetación) para que más vegetación implique **menor coste**.
- Si hay NaN/NoData se reemplazan por coste alto al calcular LCP.
