
# Guía de uso (USAGE)

## 0) Instalar
```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```
> Nota: en Debian/Ubuntu: `sudo apt install gdal-bin libgdal-dev` (requerido por rasterio/fiona).

## 1) Datos esperados
- `pendiente.tif` (P), `altitud.tif` (A), `ndvi.tif` (V), `riesgo.tif` (R), `tiempo.tif` (T en segundos).
- Capa de puntos con campo `Name`/`name` para origen/destino.

## 2) Configuración
```bash
cp config/example_config.yaml config/run.yaml
# editar rutas y pesos
```

## 3) Pipeline
**Coste** y **S**:
```bash
python src/build_cost_surface.py --config config/run.yaml
```
**LCP con coste**:
```bash
python src/lcp_from_cost.py   --cost_raster outputs/Coste.tif   --points_shp /ruta/puntos.shp   --source_name "Santiago del Estero"   --target_name "Talina"   --backend networkx   --out_path outputs/LCP_coste.shp
```
**LCP con pendiente** (baseline):
```bash
python src/lcp_from_slope.py   --slope_raster /ruta/pendiente.tif   --points_shp /ruta/puntos.shp   --source_name "Santiago del Estero"   --target_name "Talina"   --out_path outputs/LCP_pendiente.shp
```
**Mapa comparativo** (opcional):
```bash
python src/compare_paths_map.py   --lcp_cost outputs/LCP_coste.shp   --lcp_slope outputs/LCP_pendiente.shp   --out_png outputs/comparacion.png
```

## 4) Consejos
- Asegurar **mismo CRS y rejilla** para todos los rasters.
- Si NDVI alto = menor coste, usar `invert_ndvi: true` en config.
