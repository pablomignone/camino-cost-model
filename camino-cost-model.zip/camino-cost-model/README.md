# Camino Cost Model – Reproducible LCP with Historical Variables (NOA)

Este repositorio contiene el **pipeline reproducible** para calcular **Least-Cost Paths (LCP)** integrando variables
ambientales (pendiente, altitud, NDVI, tiempo) y sociales/históricas (riesgo de conflicto).

- Ver **guía de uso**: [USAGE.md](./USAGE.md)
- Requisitos: ver `requirements.txt`
- Licencia: MIT

## Resumen del flujo
1) (Opcional) Rasterizar riesgo/tiempo desde polígonos – `src/rasterize_vector.py`
2) Preparar/normalizar rasters (utilidades) – `src/utils_raster.py`
3) Construir **Supervivencia (S)** y **Coste** – `src/build_cost_surface.py`
4) Calcular **LCP con coste** – `src/lcp_from_cost.py` (backends: `networkx` o `skimage`)
5) Calcular **LCP con pendiente** – `src/lcp_from_slope.py`
6) (Opcional) Generar mapa comparativo – `src/compare_paths_map.py`
