#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Produce a simple PNG comparing LCP by cost vs slope."""
import argparse, os
import geopandas as gpd
import matplotlib.pyplot as plt

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--lcp_cost", required=True)
    ap.add_argument("--lcp_slope", required=True)
    ap.add_argument("--provinces", required=False)
    ap.add_argument("--cities", required=False)
    ap.add_argument("--out_png", required=True)
    args = ap.parse_args()

    lcp_cost = gpd.read_file(args.lcp_cost)
    lcp_slope = gpd.read_file(args.lcp_slope)

    fig, ax = plt.subplots(1,1, figsize=(10,8))
    if args.provinces:
        gpd.read_file(args.provinces).boundary.plot(ax=ax, linewidth=0.8)
    if args.cities:
        gpd.read_file(args.cities).plot(ax=ax, markersize=10, alpha=0.7)

    lcp_slope.plot(ax=ax, color=None, edgecolor="gray", linewidth=1.0, label="LCP (pendiente)")
    lcp_cost.plot(ax=ax, color=None, edgecolor="red", linewidth=1.2, label="LCP (coste)")
    ax.legend(loc="lower left")
    ax.set_title("Comparación: LCP por pendiente vs. coste multivariado")
    plt.tight_layout()
    os.makedirs(os.path.dirname(args.out_png), exist_ok=True)
    plt.savefig(args.out_png, dpi=300)

if __name__ == "__main__":
    main()
