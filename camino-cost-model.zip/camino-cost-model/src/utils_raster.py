#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Utility functions for raster alignment, normalization, and transforms."""
import numpy as np
import rasterio
import rasterio.warp
from rasterio.enums import Resampling

def read_array(path: str):
    with rasterio.open(path) as src:
        data = src.read(1)
        meta = src.meta.copy()
    return data, meta

def write_array(path: str, data: np.ndarray, meta: dict):
    meta = meta.copy()
    meta.update(dtype=rasterio.float32, count=1)
    with rasterio.open(path, "w", **meta) as dst:
        dst.write(data.astype(rasterio.float32), 1)

def normalize01(arr: np.ndarray) -> np.ndarray:
    arr = arr.astype("float64")
    finite = np.isfinite(arr)
    if not np.any(finite):
        return np.zeros_like(arr, dtype="float64")
    m, M = np.nanmin(arr[finite]), np.nanmax(arr[finite])
    if M == m:
        return np.zeros_like(arr, dtype="float64")
    out = (arr - m) / (M - m)
    out[~finite] = np.nan
    return out

def maybe_invert_ndvi(v_norm: np.ndarray, invert: bool=True) -> np.ndarray:
    if invert:
        out = 1.0 - v_norm
        return np.clip(out, 0.0, 1.0)
    return v_norm
