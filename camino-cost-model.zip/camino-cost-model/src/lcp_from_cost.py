#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Compute LCP on Cost raster; export LineString shapefile."""
import argparse, os
import numpy as np
import rasterio
import geopandas as gpd
from shapely.geometry import LineString
import networkx as nx
from skimage.graph import route_through_array

def world_to_pixel(transform, x, y):
    col, row = ~transform * (x, y)
    return int(row), int(col)

def pixel_to_world(transform, row, col):
    x, y = transform * (col + 0.5, row + 0.5)
    return (x, y)

def lcp_networkx(cost, src_rc, dst_rc):
    rows, cols = cost.shape
    G = nx.DiGraph()
    for r in range(rows):
        for c in range(cols):
            if not np.isfinite(cost[r, c]):
                continue
            for dr, dc in ((-1,0), (1,0), (0,-1), (0,1)):
                rr, cc = r+dr, c+dc
                if 0 <= rr < rows and 0 <= cc < cols and np.isfinite(cost[rr, cc]):
                    G.add_edge((r,c), (rr,cc), weight=float(cost[rr,cc]))
    path = nx.shortest_path(G, source=src_rc, target=dst_rc, weight="weight")
    return path

def lcp_skimage(cost, src_rc, dst_rc):
    idx, total = route_through_array(cost, src_rc, dst_rc, fully_connected=False, geometric=False)
    return idx

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--cost_raster", required=True)
    ap.add_argument("--points_shp", required=True)
    ap.add_argument("--source_name", required=True)
    ap.add_argument("--target_name", required=True)
    ap.add_argument("--backend", choices=["networkx","skimage"], default="networkx")
    ap.add_argument("--out_path", required=True)
    args = ap.parse_args()

    with rasterio.open(args.cost_raster) as src:
        cost = src.read(1).astype("float64")
        transform = src.transform

    pts = gpd.read_file(args.points_shp)
    name_col = "Name" if "Name" in pts.columns else "name"
    src_pt = pts.loc[pts[name_col] == args.source_name].geometry.iloc[0]
    dst_pt = pts.loc[pts[name_col] == args.target_name].geometry.iloc[0]

    src_rc = world_to_pixel(transform, src_pt.x, src_pt.y)
    dst_rc = world_to_pixel(transform, dst_pt.x, dst_pt.y)

    if not np.isfinite(cost).all():
        finite_vals = cost[np.isfinite(cost)]
        high = np.nanpercentile(finite_vals, 99.9) * 10.0 if finite_vals.size else 1e6
        cost[~np.isfinite(cost)] = high

    if args.backend == "networkx":
        path_rc = lcp_networkx(cost, src_rc, dst_rc)
    else:
        path_rc = lcp_skimage(cost, src_rc, dst_rc)

    coords = [pixel_to_world(transform, r, c) for r, c in path_rc]
    line = LineString(coords)

    gdf = gpd.GeoDataFrame({"source":[args.source_name], "target":[args.target_name]}, geometry=[line], crs=pts.crs)
    os.makedirs(os.path.dirname(args.out_path), exist_ok=True)
    gdf.to_file(args.out_path)

if __name__ == "__main__":
    main()
